#include <ListOfSinglyLinkedNodes.h>

Node * ListOfSinglyLinkedNodes :: getFirst()
{
	// Your implementation here
	return (NULL);
}

void   ListOfSinglyLinkedNodes :: setFirst(Node *newNode)
{
	// Your implementation here
}
