#include <ListOfSinglyLinkedNodes.h>

Node * ListOfSinglyLinkedNodes :: getLast()
{
	// Your implementation here
	return (NULL);
}

void   ListOfSinglyLinkedNodes :: setLast(Node *newNode)
{
	// Your implementation here
}
