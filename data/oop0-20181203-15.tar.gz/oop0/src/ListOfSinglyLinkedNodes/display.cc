#include "ListOfSinglyLinkedNodes.h"
#include <stdio.h>

void ListOfSinglyLinkedNodes :: display(int mode)
{
	// Your implementation here
}
