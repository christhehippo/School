#include <DoublyLinkedNode.h>

Node * DoublyLinkedNode :: copy()
{
	// Youl implementation here

	return (NULL);
}
