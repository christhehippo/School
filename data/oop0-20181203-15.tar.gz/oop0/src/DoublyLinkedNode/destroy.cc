#include <DoublyLinkedNode.h>

DoublyLinkedNode :: ~DoublyLinkedNode()
{
	// Your implementation here
}
