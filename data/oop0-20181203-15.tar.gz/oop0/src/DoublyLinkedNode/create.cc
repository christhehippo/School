#include <DoublyLinkedNode.h>

DoublyLinkedNode :: DoublyLinkedNode()
{
	// Your implementation here
}

DoublyLinkedNode :: DoublyLinkedNode(int value)
{
	// Your implementation here
}
