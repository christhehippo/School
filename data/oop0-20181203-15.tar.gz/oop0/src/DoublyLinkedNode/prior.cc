#include <DoublyLinkedNode.h>

void DoublyLinkedNode :: setPrior(Node *priorNode)
{
	// Your implementation here
}

Node * DoublyLinkedNode :: getPrior()
{
	// Your implementation here
	return(NULL);
}
