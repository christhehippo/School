#include "ListOfDoublyLinkedNodes.h"
#include <stdio.h>

void ListOfDoublyLinkedNodes :: display(int mode)
{
	// Your implementation here
}
