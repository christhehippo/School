#include <ListOfDoublyLinkedNodes.h>

List * ListOfDoublyLinkedNodes :: copy()
{
    // Your implementation here

    return (NULL);
}
