#include <ListOfDoublyLinkedNodes.h>

ListOfDoublyLinkedNodes :: ListOfDoublyLinkedNodes()
{
	this -> setQuantity(0);
	this -> setFirst(NULL);
	this -> setLast (NULL);
}
