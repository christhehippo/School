#include <List.h>

List :: ~List()
{
	quantity = 0;
}
