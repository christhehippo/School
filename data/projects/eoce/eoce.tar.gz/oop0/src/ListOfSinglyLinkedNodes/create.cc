#include <ListOfSinglyLinkedNodes.h>

ListOfSinglyLinkedNodes :: ListOfSinglyLinkedNodes()
{
	this -> setQuantity(0);
	this -> first    = NULL;
	this -> last	 = NULL;
}
