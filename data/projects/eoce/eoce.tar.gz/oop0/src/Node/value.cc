#include <Node.h>

void Node :: setValue(int value)
{
	this -> value = value;
}

int  Node :: getValue()
{
	return(this -> value);
}
