#include <Node.h>

Node ::	~Node()
{
	value = 0;
}
