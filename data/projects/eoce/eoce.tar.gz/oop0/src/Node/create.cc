#include <Node.h>

Node :: Node()
{
	value = 0;
}

Node :: Node(int value)
{
	this -> value = value;
}
